import React from 'react';
import Input from './component/Input.js'
import './App.css';
import Router from './routes'

function App() {
  return (
    <div className="App">
       <Input />
      <Router />
    </div>
  );
}

export default App;
